package ragavi.com.retrofit25

import com.google.gson.annotations.SerializedName

data class Beer(
    @SerializedName("name") val name: String,
    @SerializedName("brewery") val brewery: String,
    @SerializedName("style") val style: String,
    @SerializedName("image") val image: String
)