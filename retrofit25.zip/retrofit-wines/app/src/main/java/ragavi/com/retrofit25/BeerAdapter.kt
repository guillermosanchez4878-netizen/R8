package ragavi.com.retrofit25

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class BeerAdapter(private val beers: List<Beer>) :
    RecyclerView.Adapter<BeerAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.name)
        val brewery: TextView = view.findViewById(R.id.brewery)
        val style: TextView = view.findViewById(R.id.style)
        val image: ImageView = view.findViewById(R.id.image)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_beer, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = beers.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val beer = beers[position]

        holder.name.text = beer.name
        holder.brewery.text = beer.brewery
        holder.style.text = beer.style

        Glide.with(holder.itemView.context)
            .load(beer.image)
            .into(holder.image)
    }
}