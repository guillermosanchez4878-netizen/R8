package ragavi.com.retrofit25

import retrofit2.Call
import retrofit2.http.GET

interface WineApiService {

    @GET("beers/ale")
    fun getBeers(): Call<List<Beer>>
}